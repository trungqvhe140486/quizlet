/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entity.Course;
import entity.Question;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ylbee
 */
public class CourseDAO extends DAO{
//    public List<Question> getQuestionByCourseId(int courseId) throws SQLException {
//        
//        ArrayList<Question> list = new ArrayList();
//        String sql = "select q.*\n"
//                + "from Question as q\n"
//                + "join Course as c\n"
//                + "on q.courseid = c.courseid";
//        ps = con.prepareStatement(sql);
//            ps.setInt(1, Integer.parseInt(cid));
//            rs = ps.executeQuery();
//        
//        while(rs.next()) {
//            int questionid = rs.getInt("questionid");
//            String question = rs.getString("image");
//            String term = rs.getString("term");
//            String definition = rs.getString("definition");
//            int courseid = rs.getInt("courseid");
//            list.add(new Question(questionid, courseid, question, term, definition));
//        }
//        return list;
//        
//    }
     public List<Course> getAllCourses(){
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM Course";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                courses.add(new Course(rs.getInt("courseid"), rs.getString("title"), rs.getString("description"), rs.getBoolean("visibleto"), rs.getInt("accountid")))  ;
            }
        } catch (SQLException e) {
        }
        return courses;
    }
    
//    public static void main(String[] args) {
//        List<Course> courses = new CourseDAO().getAllCourses();
//        for (Course course : courses) {
//            System.out.println(course);
//        }
//    }
}
