/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Course;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CourseDAO;
import entity.User;
import model.UserDAO;

/**
 *
 * @author thopn
 */
//public class LoginController extends HttpServlet {
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        request.getRequestDispatcher("login.jsp").forward(request, response);
//    }
//
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        String user = request.getParameter("txtUser");
//        String pass = request.getParameter("txtPass");
//        CourseDAO dao = new CourseDAO();
//        Course objUser = dao.get ;
//        if (objUser != null) {
//            request.getSession().setAttribute("currUser", objUser);
//            if (objUser.getRole() == 1) {
//                request.getRequestDispatcher("admin").forward(request, response);
//            } else if (objUser.getRole() == 2) {
//                request.getRequestDispatcher("index.jsp").forward(request, response);
//            }
//        } else {
//            response.sendRedirect("index.jsp");
//        }
//    }
//}
