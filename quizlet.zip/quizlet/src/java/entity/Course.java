/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author dinhthituoi
 */
public class Course {
    private int Courseid;
    private String title, desciption;
    private boolean visibleto;
    private int account_id;

    public Course() {
    }

    public Course(int Courseid, String title, String desciption, boolean visibleto, int account_id) {
        this.Courseid = Courseid;
        this.title = title;
        this.desciption = desciption;
        this.visibleto = visibleto;
        this.account_id = account_id;
    }

    public int getCourseid() {
        return Courseid;
    }

    public void setCourseid(int Courseid) {
        this.Courseid = Courseid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesciption() {
        return desciption;
    }

    public void setDesciption(String desciption) {
        this.desciption = desciption;
    }

    public boolean isVisibleto() {
        return visibleto;
    }

    public void setVisibleto(boolean visibleto) {
        this.visibleto = visibleto;
    }

    public int getAccount_id() {
        return account_id;
    }

    public void setAccount_id(int account_id) {
        this.account_id = account_id;
    }

    @Override
    public String toString() {
        return "Course{" + "Courseid=" + Courseid + ", title=" + title + ", desciption=" + desciption + ", visibleto=" + visibleto + ", account_id=" + account_id + '}';
    }

    

    
}
