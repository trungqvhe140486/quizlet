/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author dinhthituoi
 */
public class Question {
    private int id, course_id;
    private String question, term, definition;

    public Question() {
    }

    public Question(int id, int course_id, String question, String term, String definition) {
        this.id = id;
        this.course_id = course_id;
        this.question = question;
        this.term = term;
        this.definition = definition;
    }
    private boolean isCorrect;
    public int getId() {
        return id;
    }
    public String getIdString() {
        return "" + id;
    }

    public boolean isIsCorrect() {
        return isCorrect;
    }

    public void setIsCorrect(boolean isCorrect) {
        this.isCorrect = isCorrect;
    }
    
    

    public void setId(int id) {
        this.id = id;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }
    
}
